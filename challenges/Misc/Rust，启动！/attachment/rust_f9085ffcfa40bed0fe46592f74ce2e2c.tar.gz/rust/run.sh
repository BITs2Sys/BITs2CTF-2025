#!/bin/sh

echo $GZCTF_FLAG >./flag

su - ctf -c 'cd /home/ctf/cli || exit 1 && uv run ./main.py'
