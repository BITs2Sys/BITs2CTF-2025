#!/bin/sh

#export BITS2FLAG="flag{fake_flag}"

su - ctf -c 'cd /home/ctf/cli || exit 1 && uv run ./main.py'
