#!/bin/sh

LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$(pwd) $(pwd)/httpd
