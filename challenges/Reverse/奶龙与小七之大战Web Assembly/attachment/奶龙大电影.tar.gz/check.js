import { check } from "./check.wasm";

console.log("============================");
console.log(" | 奶龙与小七之大战wasm!! | ");
console.log("============================");

console.log("暴暴龙带着他的新发明Wasm来挑战你了！");

console.log("你能帮助小七破解暴暴龙的Wasm的奥秘吗？");

const flag =
  "BITs2CTF{xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}";

const enc = [
  75,
  66,
  89,
  124,
  51,
  64,
  81,
  65,
  98,
  76,
  46,
  46,
  32,
  76,
  113,
  39,
  71,
  24,
  12,
  112,
  120,
  19,
  80,
  0,
  79,
  8,
  98,
  10,
  68,
  80,
  86,
  4,
  124,
  126,
  43,
  58,
  112,
  114,
  60,
  24,
  61,
  104,
  59,
  108,
  101,
  100,
  102,
  51,
  54,
  92,
  5,
  92,
  62,
  91,
  81,
  87,
  65,
  79,
  77,
  78,
  65,
  29,
  67,
  40,
  189,
  229,
  233,
  208,
  233,
  178,
  176,
  216,
  206,
  175,
  168,
  242,
  236,
];

let chk = 0;

for (let i = 0; i < enc.length; i += 1) {
  if (check(i, flag[i].charCodeAt(), enc[i]) != 1) {
    chk = 1;
    break;
  }
}

if (chk == 0) {
  console.log("你成功打败了暴暴龙和他的Wasm！");
} else {
  console.log("不好！你被暴暴龙的Wasm击败了。。。");
}
