#!/bin/sh
# Start xinetd service
echo "$GZCTF_FLAG" >/home/ctf/flag
# DO NOT DELETE
/etc/init.d/xinetd start
sleep infinity
