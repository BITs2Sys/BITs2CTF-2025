# BIT-Compiler CTF Challenge

A compiler challenge using LLVM/Clang with custom OraclePass plugin in a chroot environment.

## Quick Start

### Build
```bash
docker build -t bit-compiler .
```

### Run
```bash
docker run -d -p 9999:9999 --name bit-compiler bit-compiler
```

### Upload & Test
```bash
python3 upload.py 127.0.0.1 9999 solver.c
```

Or manually with netcat:
```bash
nc 127.0.0.1 9999
# Paste your C code, then type EOF on a new line
```

### Stop & Clean
```bash
docker stop bit-compiler && docker rm bit-compiler
```

## Challenge Structure

- `bin/server.py` - Main challenge server (runs in chroot)
- `compiler/` - OraclePass LLVM plugin source code
- `solver.c` - Example solution
- `upload.py` - Helper script to upload code

## Notes

- Max file size: 10KB
- Compilation timeout: 10 seconds
- Code is compiled with `-fpass-plugin=/compiler/build/OraclePass.so`
- Flag is revealed when compilation output contains "congratulation"
