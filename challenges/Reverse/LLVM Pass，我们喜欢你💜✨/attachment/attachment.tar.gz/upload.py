#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Upload script for BIT-Compiler Challenge
Usage: python3 upload.py <host> <port> <source_file.c>
"""

import socket
import sys
import os
import time

def upload_code(host, port, source_file):
    """Upload C source code to the challenge server"""
    
    # Check if source file exists
    if not os.path.exists(source_file):
        print(f"[-] Error: File '{source_file}' not found!")
        return False
    
    # Read source code
    try:
        with open(source_file, 'r') as f:
            code = f.read()
    except Exception as e:
        print(f"[-] Error reading file: {e}")
        return False
    
    # Check file size
    if len(code) > 10240:
        print("[-] Error: File too large (max 10KB)")
        return False
    
    print(f"[+] Connecting to {host}:{port}...")
    
    try:
        # Connect to server
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(120)  # 2 minutes timeout
        sock.connect((host, int(port)))
        
        print("[+] Connected!")
        print("[+] Receiving banner...")
        
        # Receive and display banner
        banner = ""
        while True:
            data = sock.recv(1024).decode('utf-8', errors='ignore')
            if not data:
                break
            banner += data
            print(data, end='', flush=True)
            
            # Check if we've received the full banner
            if "EOF" in data or "End your input" in data:
                break
            
            # Avoid infinite loop
            if len(banner) > 2000:
                break
        
        print("\n[+] Sending source code...")
        
        # Send source code line by line
        for line in code.split('\n'):
            sock.sendall((line + '\n').encode('utf-8'))
            time.sleep(0.01)  # Small delay to avoid overwhelming the server
        
        # Send EOF marker
        sock.sendall(b'EOF\n')
        print("[+] Code sent! Waiting for compilation result...")
        
        # Receive and display response
        response = ""
        sock.settimeout(60)  # 1 minute for compilation
        
        while True:
            try:
                data = sock.recv(4096).decode('utf-8', errors='ignore')
                if not data:
                    break
                response += data
                print(data, end='', flush=True)
            except socket.timeout:
                print("\n[-] Timeout waiting for response")
                break
            except Exception as e:
                break
        
        print()  # New line
        
        # Check if we got the flag
        if "flag" in response.lower() or "BITCTF{" in response:
            print("\n" + "="*60)
            print("[+] SUCCESS! Flag received!")
            print("="*60)
        elif "congratulation" in response.lower():
            print("\n[+] Compilation passed!")
        else:
            print("\n[-] Compilation failed or checks not passed")
        
        sock.close()
        return True
        
    except socket.timeout:
        print("[-] Connection timeout")
        return False
    except ConnectionRefusedError:
        print(f"[-] Connection refused. Is the server running on {host}:{port}?")
        return False
    except Exception as e:
        print(f"[-] Error: {e}")
        return False

def main():
    if len(sys.argv) != 4:
        print("Usage: python3 upload.py <host> <port> <source_file.c>")
        print()
        print("Examples:")
        print("  python3 upload.py localhost 9999 solver.c")
        print("  python3 upload.py 127.0.0.1 9999 solution.c")
        print("  python3 upload.py ctf.example.com 10001 exploit.c")
        sys.exit(1)
    
    host = sys.argv[1]
    port = sys.argv[2]
    source_file = sys.argv[3]
    
    print("="*60)
    print("BIT-Compiler Challenge - Upload Script")
    print("="*60)
    print(f"Target: {host}:{port}")
    print(f"Source: {source_file}")
    print("="*60)
    print()
    
    success = upload_code(host, port, source_file)
    
    if success:
        print("\n[+] Done!")
        sys.exit(0)
    else:
        print("\n[-] Failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()
